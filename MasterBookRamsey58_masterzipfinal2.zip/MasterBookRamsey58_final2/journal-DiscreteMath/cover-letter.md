# Cover letter

To the Editors of *Discrete Mathematics*

Dear Editors,

I submit the manuscript "The book Ramsey number R(B_57, B_58) = 231" for consideration.

The book B_k is k triangles sharing an edge. Rousseau and Sheehan (1978) proved
R(B_{n−1}, B_n) ≤ 4n − 1, and W. J. Wesley (*Lower bounds for book Ramsey numbers*, Discrete
Math. 349 (2026), 114913) proved equality for n ≤ 20 and whenever 2n − 1 is a prime power
congruent to 1 modulo 4, and conjectured equality for every n. Constructions of Turturean, of
Chung, Du and Wesley, and of Price have since settled the conjecture for every n ≤ 57 and for a
sparse set of larger n; n = 58 was the smallest case left open.

The manuscript proves R(B_57, B_58) = 231. The lower bound is a graph on 230 vertices, a two-block
circulant graph over Z_115 of the shape Turturean uses for even n. The paper reduces both book
conditions for graphs of this shape to one inequality per nonzero residue and lists the 57
inequalities that matter in a table, so the proof can be checked by hand. The graph was found by a
computer search and is checked by two independent programs; the equality itself, including the
upper bound of Rousseau and Sheehan, is also proved in Lean 4 and checked by the kernel with only
the standard axioms. The data, programs and proof are publicly available.

The manuscript is not under consideration elsewhere. I declare no competing interests and no
funding.

Yours sincerely,

Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de, itsdeep@live.com, ORCID 0000-0003-0466-750X
