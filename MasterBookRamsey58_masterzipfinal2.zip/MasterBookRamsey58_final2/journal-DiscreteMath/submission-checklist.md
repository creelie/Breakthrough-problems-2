# Submission checklist: Discrete Mathematics

Journal: *Discrete Mathematics* (Elsevier), which published Wesley's paper stating the
conjecture. Submission through Elsevier's Editorial Manager, linked from
https://www.sciencedirect.com/journal/discrete-mathematics.
Fallbacks: *The Electronic Journal of Combinatorics*; *Journal of Graph Theory*; *Australasian
Journal of Combinatorics*.

Files to upload:

1. `dm-manuscript-final2.pdf`: the manuscript in Elsevier's class `elsarticle` (10 pages).
2. `dm-manuscript-source-final2.zip`: `main.tex` and the two PNG figures; it compiles with
   `pdflatex main.tex` (three runs) on any TeX Live with `elsarticle`.
3. `cover-letter.md`: paste into the cover-letter field.

Metadata to enter:

- Title: The book Ramsey number R(B_57, B_58) = 231
- Article type: Research paper (it is short; *Note* is also possible if the system offers it)
- Author: Deep Bhattacharjee (sole author, corresponding), ORCID 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar,
  Odisha 751030, India
- Keywords: Ramsey number; book graph; block-circulant graph; local search; formal verification
- MSC 2020: 05C55 (primary); 05C25, 05B10 (secondary)

Only the author can confirm:

- [ ] "This research did not receive any specific grant ..." (stated under Funding)
- [ ] "The author has no competing interests to declare." (stated under Declaration of competing
      interest)
- [ ] the generative AI declaration at the end of the manuscript
- [ ] postal address and telephone number, if the system asks for them
- [ ] suggested referees, if the system asks (people who work on book Ramsey numbers or circulant
      Ramsey constructions and are not coauthors of the author)

Before submitting, optionally post the arXiv tarball (`book-ramsey-58_final2-arxiv.tar.gz`) to
arXiv (math.CO); the journal does not require it. Recheck the open values just before submitting:
the Station team (Chung, Du and Wesley) publish new cases in their data repository, and the paper's
footnote dates its list to 15 October 2026.
