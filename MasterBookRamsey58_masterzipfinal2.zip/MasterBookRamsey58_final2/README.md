# The book Ramsey number R(B_57, B_58) = 231: master package

Author: Deep Bhattacharjee, formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL),
Bhubaneswar, Odisha 751030, India. d.bhattacharjee@erl-forschung.de, itsdeep@live.com,
ORCID 0000-0003-0466-750X.

**What is proved.** R(B_57, B_58) = 231, the case n = 58 of Wesley's conjecture
R(B_{n−1}, B_n) = 4n − 1. It was the smallest open case of the conjecture on 15 October 2026, and
the priority check of that day (`PRIORITY-CHECK.md`) found no earlier source. The lower bound is a
graph on 230 vertices, a two-block circulant graph over Z_115, with no B_57 whose complement has no
B_58; the upper bound is that of Rousseau and Sheehan.

**What it is not.** It is one new value, found by a computer search and proved by a finite check.
It does not prove Wesley's conjecture, which stays open: for n ≤ 100 the open values are now 59, 60,
64, 65, 68, 72, 73, 76, 78, 80, 81, 84, 88, 89, 92, 93, 94, 96 and 100.

- Repository: https://github.com/creelie/Breakthrough-problems-2
- Zenodo: concept DOI 10.5281/zenodo.23373628 (all versions); v2.0.0 is [10.5281/zenodo.23393415](https://doi.org/10.5281/zenodo.23393415)

## Contents

| File | What it is |
|---|---|
| `book-ramsey-58_final2.pdf` | the paper (amsart, 6 pages) |
| `book-ramsey-58_final2-tex.zip` | its LaTeX source with the figures as PNG |
| `book-ramsey-58_final2-arxiv.tar.gz` | the same as an arXiv tarball |
| `journal-DiscreteMath/` | the manuscript formatted for *Discrete Mathematics* (elsarticle, 10 pages), its source, the cover letter and the submission checklist |
| `PRIORITY-CHECK.md` | the dated priority checks, for n = 58 (15 October 2026) and n = 67 |
| `repository/` | the repository at release v2.0.0: data, Lean 4 proofs, C and Python checks, the search, the paper sources |

## What is proved, and where

- The paper proves the result by hand: both book conditions reduce to one inequality per nonzero
  residue, and its Table 1 lists the 57 values that matter.
- `repository/lean/` proves `book_ramsey_58 : IsBookRamsey 57 58 231` in Lean 4 (core Lean v4.35.0,
  no Mathlib): 231 is the least N such that every graph on N vertices contains B_57 or has a
  complement containing B_58. The kernel checks the graph on all 26,335 pairs of vertices
  (`decide +kernel`, no `native_decide`), and Goodman's count, formalised for every graph, gives the
  upper bound. Only the axioms `propext`, `Classical.choice` and `Quot.sound` occur
  (`repository/verification/axioms.txt`).
- The same counts are recomputed independently in C and in Python, and every number printed in the
  paper is recomputed from its source (`repository/scripts/run_all.sh`).

The repository also holds a hand-checkable proof of R(B_66, B_67) = 267, a value first shown by
Chung, Du and Wesley in the Station data of 24 August 2026 and not new here.

The author used Claude (Anthropic) to search for the example, to check it by computer and in Lean,
and to draft the text; the author verified every step and is responsible for the content.
