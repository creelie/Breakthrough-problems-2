# A hand-checkable proof that R(B_66, B_67) = 267: master package

Author: Deep Bhattacharjee, formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL),
Bhubaneswar, Odisha 751030, India. d.bhattacharjee@erl-forschung.de, itsdeep@live.com,
ORCID 0000-0003-0466-750X.

**The value is not new.** R(B_66, B_67) = 267, the case n = 67 of Wesley's conjecture
R(B_{n−1}, B_n) = 4n − 1, was first shown by Stephen Chung, Wenyu Du and William J. Wesley in the
data accompanying their Station paper (arXiv:2608.23691), published on 24 August 2026:
https://github.com/dualverse-ai/station_data_v2, `artifacts/book_ramsey/verification.ipynb`,
Section 5.1, certificate `finite_n67`. The graph found here independently is isomorphic to theirs
(`repository/verification/python/station_isomorphism.py`). The first version of this package
presented the value as new and contained a Discrete Mathematics submission; both were wrong and are
withdrawn. The paper here does not settle a new value and should not be submitted as one.

What the paper adds: a description of the graph as a two-block circulant graph on Z_133 × {0, 1}
whose connection sets are unions of orbits of the cube roots of unity modulo 133, a proof that both
book conditions reduce to one inequality checked by hand on ten orbits, and a Lean 4 kernel check.

- Repository: https://github.com/creelie/Breakthrough-problems-2
- Zenodo: concept DOI 10.5281/zenodo.23373628 (all versions); v1.0.1 is 10.5281/zenodo.23377549 (v1.0.0, 10.5281/zenodo.23373629, is superseded)

## Contents

| File | What it is |
|---|---|
| `book-ramsey-67_final2.pdf` | the corrected paper (amsart, 6 pages) |
| `book-ramsey-67_final2-tex.zip` | its LaTeX source with the figures as PNG |
| `book-ramsey-67_final2-arxiv.tar.gz` | the same as an arXiv tarball |
| `PRIORITY-CHECK.md` | the dated priority check, with the source it first missed |
| `repository/` | the repository at the corrected commit: data, Lean 4 proof, C and Python checks, the isomorphism with the Station certificate, the search, the paper sources |

## What is proved, and where

- The graph and its two book properties (every edge in at most 65 triangles; every non-adjacent pair
  with at most 66 common non-neighbours) are checked by the Lean 4 kernel in `repository/lean/`
  (core Lean v4.35.0, `decide +kernel`, no `native_decide`; axioms `propext`, `Classical.choice`,
  `Quot.sound` only, see `repository/verification/axioms.txt`).
- The same counts are recomputed independently in C and in Python (`repository/scripts/run_all.sh`).
- The paper proves the result by hand on the ten orbits of ±H (its Table 1).

## What is open

- Wesley's conjecture stays open. For n ≤ 100 the values 58, 59, 60, 64, 65, 68, 72, 73, 76, 78,
  80, 81, 84, 88, 89, 92, 93, 94, 96 and 100 are open; this package settles none of them.
- Two steps are proved in the paper and not in Lean: the translation from the graph property to
  R(B_66, B_67) > 266, and the upper bound R(B_66, B_67) ≤ 267 of Rousseau and Sheehan.

The author used Claude (Anthropic) to search for the example, to check it by computer and in Lean,
and to draft the text; the author verified every step and is responsible for the content.
