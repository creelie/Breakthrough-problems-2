# The book Ramsey number R(B_66, B_67) = 267: master package

Author: Deep Bhattacharjee, formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL),
Bhubaneswar, Odisha 751030, India. d.bhattacharjee@erl-forschung.de, itsdeep@live.com,
ORCID 0000-0003-0466-750X.

Result: R(B_66, B_67) = 267, the case n = 67 of Wesley's conjecture R(B_{n−1}, B_n) = 4n − 1
(Discrete Math. 349 (2026), 114913). The upper bound is Rousseau and Sheehan (1978); the lower bound
is a two-block circulant graph on Z_133 × {0, 1} with no B_66 whose complement has no B_67.

- Repository: https://github.com/creelie/Breakthrough-problems-2
- Release v1.0.0: https://github.com/creelie/Breakthrough-problems-2/releases/tag/v1.0.0
- Zenodo: version DOI 10.5281/zenodo.23373629 (https://doi.org/10.5281/zenodo.23373629), concept
  DOI 10.5281/zenodo.23373628

## Contents

| File | What it is |
|---|---|
| `book-ramsey-67_final2.pdf` | the paper (amsart, 3D TikZ figures) |
| `book-ramsey-67_final2-tex.zip` | its LaTeX source with the figures as PNG |
| `book-ramsey-67_final2-arxiv.tar.gz` | the arXiv submission (math.CO) |
| `journal-DiscreteMath/dm-manuscript-final2.pdf` | the manuscript in Elsevier's `elsarticle`, for Discrete Mathematics (9 pages) |
| `journal-DiscreteMath/dm-manuscript-source-final2.zip` | its source: `main.tex` and two PNG figures; compiles with three runs of `pdflatex` |
| `journal-DiscreteMath/cover-letter.md` | the cover letter |
| `journal-DiscreteMath/submission-checklist.md` | the upload steps, the metadata, and what only the author can confirm |
| `PRIORITY-CHECK.md` | the dated check (14 October 2026) that nobody had settled n = 67 before |
| `repository/` | the repository at the commit that records the DOI: data, Lean 4 proof, C and Python checks, the search, the paper sources |

## What is proved, and where

- The graph and its two book properties (every edge in at most 65 triangles; every non-adjacent pair
  with at most 66 common non-neighbours) are checked by the Lean 4 kernel in `repository/lean/`
  (core Lean v4.35.0, `decide +kernel`, no `native_decide`; axioms `propext`, `Classical.choice`,
  `Quot.sound` only, see `repository/verification/axioms.txt`).
- The same counts are recomputed independently in C and in Python (`repository/scripts/run_all.sh`).
- The paper proves the result by hand: both book conditions reduce to one inequality on the ten
  orbits of ±H, checked in its Table 1.

## What is open or not formalized

- Wesley's conjecture itself stays open. For n ≤ 100 the values 58, 59, 60, 64, 65, 68, 72, 73, 76,
  78, 80, 81, 84, 88, 89, 92, 93, 94, 96 and 100 are still open; only n = 67 is settled here.
- Two steps are proved in the paper and not in Lean: the translation from the graph property to
  R(B_66, B_67) > 266 (an edge in k triangles is the spine of a B_k), and the upper bound
  R(B_66, B_67) ≤ 267 of Rousseau and Sheehan.

## Funding and competing interests

The manuscript states that the research received no specific grant and that the author has no
competing interests; the author should confirm both before submitting (see the checklist).

The author used Claude (Anthropic) to search for the example, to check it by computer and in Lean,
and to draft the text; the author verified every step and is responsible for the content.
