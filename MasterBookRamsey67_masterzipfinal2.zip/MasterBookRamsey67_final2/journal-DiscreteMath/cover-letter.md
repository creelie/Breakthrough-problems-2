# Cover letter

To the Editors of *Discrete Mathematics*

Dear Editors,

I submit the manuscript "The book Ramsey number R(B_66, B_67)" for consideration.

The book B_k is k triangles sharing an edge. Rousseau and Sheehan (1978) proved
R(B_{n-1}, B_n) ≤ 4n − 1, and W. J. Wesley (*Lower bounds for book Ramsey numbers*, Discrete
Math. 349 (2026), 114913) proved equality for n ≤ 20 and whenever 2n − 1 is a prime power
congruent to 1 modulo 4, and conjectured equality for every n. Constructions of Turturean, of
Chung, Du and Wesley, and of Price have since settled the conjecture for every n ≤ 56 and for a
sparse set of larger n; n = 67 was not among them.

The manuscript proves R(B_66, B_67) = 267. The lower bound is a graph on 266 vertices: a two-block
circulant graph over Z_133 whose connection sets are unions of orbits of the group of cube roots of
unity modulo 133. The paper reduces the book condition for such graphs to one inequality per
nonzero residue and verifies the inequalities by hand from a table of orbit-pair counts. The same
graph is checked by two independent programs and by a proof in Lean 4 checked by the kernel, with
only the standard axioms; the data, programs and proof are publicly available.

The manuscript is not under consideration elsewhere. I declare no competing interests and no
funding.

Yours sincerely,

Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de, itsdeep@live.com, ORCID 0000-0003-0466-750X
